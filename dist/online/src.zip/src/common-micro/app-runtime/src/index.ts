//按照Webpack ModuleFederation方案，原入口文件改名为bootstrap.ts
// @ts-ignore
import bootstrap from './bootstrap';

bootstrap(() => undefined);
