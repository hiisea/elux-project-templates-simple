// @ts-ignore
import bootstrap from './bootstrap';

bootstrap(() => undefined);
