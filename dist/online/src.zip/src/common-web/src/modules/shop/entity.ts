export enum CurView {
  'list' = 'list',
}
