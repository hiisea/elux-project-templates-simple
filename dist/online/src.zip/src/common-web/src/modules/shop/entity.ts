export enum CurView {
  'list' = 'list',
}

class API {}

export const api = new API();
