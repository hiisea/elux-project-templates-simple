class API {}

export default new API();