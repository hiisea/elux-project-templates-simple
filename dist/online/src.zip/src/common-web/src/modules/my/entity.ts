export interface UpdateUserInfo {
  nickname: string;
}

export enum CurView {
  'userSummary' = 'userSummary',
}

class API {}

export const api = new API();
