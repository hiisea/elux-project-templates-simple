export const HomeUrl: string = '/*# =admin?/admin/article/list:/article/list #*/';
export const LoginUrl: string = '/stage/login';
