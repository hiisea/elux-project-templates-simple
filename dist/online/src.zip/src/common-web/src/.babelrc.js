module.exports = {
  presets: [['@elux', {ui: '<%= framework %>'}]],
};
