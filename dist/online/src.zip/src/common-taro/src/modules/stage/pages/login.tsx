import {EluxPage} from '<%= elux %>';

definePageConfig({
  navigationBarTitleText: '登录',
});

export default EluxPage;
