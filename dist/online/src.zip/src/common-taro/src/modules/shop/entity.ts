export type CurrentView = 'goodsList';

class API {}

export const api = new API();
