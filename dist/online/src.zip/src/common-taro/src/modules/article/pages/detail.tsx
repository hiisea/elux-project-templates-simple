import {EluxPage} from '<%= elux %>';

definePageConfig({
  navigationBarTitleText: '文章详情',
});

export default EluxPage;
