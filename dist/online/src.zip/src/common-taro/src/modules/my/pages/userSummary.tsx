import {EluxPage} from '<%= elux %>';

definePageConfig({
  navigationBarTitleText: '个人中心',
});

export default EluxPage;
